window.textFrame1 = ['НАСЛАЖДАЙСЯ ПРАЗДНИКОМ!'];
window.textFrame2 = ['ЗАРЯДИСЬ', 'НАСТРОЕНИЕМ!'];
